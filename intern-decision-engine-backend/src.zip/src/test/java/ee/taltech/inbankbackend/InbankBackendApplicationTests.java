package ee.taltech.inbankbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InbankBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
